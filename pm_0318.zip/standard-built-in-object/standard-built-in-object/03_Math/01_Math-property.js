/* 01_Math-property
표준 빌트인 객체 Math는 수학적인 상수와 함수를 위한 프로퍼티와 메서드를 제공한다.
Math는 생성자 함수가 아니므로 정적 프로퍼티와 정적 메서드만 제공한다.
*/

// Math 프로퍼티
// Math.PI : 원주율 PI 값을 반환한다.
console.log(Math.PI);