/**
 * 문자열 타입
 */

let str1 = "안녕";
let str2 = "소영이다";
let str3 = "문자열과 함께";
