/**
 * 데이터 타입의 종류
 *  number 숫자
 * [let num = 1;]
 * string 문자
 * [let name = '길동이';]
 * boolean 불 참, 거짓
 * [let isFree = false;]
 * null 비었다.
 * undefinde 정의되지 않았다.
 * [let sample = '';
 * consloe.log('sample-', sample);]
 * symbol
 * object 객체
 * [const obj1 = {
 * a: 'test1',
 * b: () => {},
 * c: [],
 * d: {}
 * };]
 *
 * 원시타입: 메모리 타입?
 * 객체타입: 메모리 값을 변경할 수 있다 변경 가능한 값을 넣는다?
 */
