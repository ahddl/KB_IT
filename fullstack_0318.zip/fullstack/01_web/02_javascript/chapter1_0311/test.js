var num = 10;
var test2 = "10";

console.log("num은", num, "test2는", test2);
console.log(`num은 ${num} test2는 ${test2} `);

let array = ["가", "나", "다"];

console.log(array);
console.log(array.length);

array.push("꺅");
console.log(array);

console.log(array.length);
