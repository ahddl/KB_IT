var color = require("ansi_color");

function inputName(name) {
  console.log(`color(${name}, green)님, 안녕하세요?`);
}

inputName("홍길동");
